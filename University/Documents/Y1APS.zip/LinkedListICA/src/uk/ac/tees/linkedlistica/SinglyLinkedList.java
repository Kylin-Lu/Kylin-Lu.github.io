package uk.ac.tees.linkedlistica;

/**
 * Represents a singly linked list.
 * @author Kylin Lu (D3013539@tees.ac.uk)
 * @author Annalisa Occhipinti (a.occhipinti@tees.ac.uk)
 */
public class SinglyLinkedList {
    
    /**
     * Stores the first node in the list.
     */
    public ListNode head;
    
    /**
     * Creates a new singly linked list from an existing array.
     * @param data  the array to create the new linked list from
     */
    public SinglyLinkedList(int[] data) {
        
        // DO NOT MODIFY THIS CONSTRUCTOR.
        
        // Populate list.
        for (int i = data.length - 1; i >= 0; i--) {
            head = new ListNode(data[i], head);
        }
    }
    
    /**
     * Creates a new, empty singly linked list.
     */
    public SinglyLinkedList() {
        
        // DO NOT MODIFY THIS CONSTRUCTOR.
        
        this(new int[] {});
    }
    
    /**
     * Gets the length of the doubly linked list.
     * @return  the length
     */
    public int getSize() {
        ListNode p = head;
        int size = 0;
        
        while(p != null){
            size ++;
            p = p.next;
        }
        
        return size;  
    }
    
    
    /**
     * @return the second item of the list.
     *         or -999 if there is only one item
     */
    public int getSecond() {   
        ListNode p = head;
        int secondNode = -999;
        
        if(p.next != null){
            secondNode = p.next.data;
        }
        
        return secondNode;
    }
    
    /**
     * Gets the item at the specified index in the list.
     * @param index the index
     * @return      the item, or -999 if not found
     */
    public int getAtPos(int index) {
        // Using -999 instead of -1 in the document
        ListNode p = head;
        
        for(int i = 0; i < index; i++){
            if(p.next == null){
                return -999;
            }
            else{
                p = p.next;
            }
        }
        
        return p.data;
    }
    
    
    
    /**
     * Adds an item after a specified index in the list.
     * @param obj   the item to add
     * @param index the index
     * @return      true if successful, otherwise false
     */
    public boolean addAfterPos(int obj, int index) {
        ListNode p = head;
        
        for(int i = -1; i < index - 1; i++){
            if(p.next == null){
                return false;
            }
            else{
                p = p.next;
            }
        }
        
        p.next = new ListNode(obj, p.next);
        
        return true;
    }
    
    
    /**
     * Reverses the order of this linked list.
     */
    public void reverseOrderLinkedList() {
        ListNode p = head.next;
        ListNode temp = p.next;
        head.next = null;
        p.next = head;
        
        while(temp != null){
            head = p;
            p = temp;
            temp = p.next;
            p.next = head;
        }

        head = p;
    }
    
}
