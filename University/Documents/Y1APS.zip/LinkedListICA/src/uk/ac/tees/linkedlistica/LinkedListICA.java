package uk.ac.tees.linkedlistica;

/**
 * The project main class (intentionally empty).
 * @author Kylin Lu (D3013539@tees.ac.uk)
 * @author Annalisa Occhipinti (a.occhipinti@tees.ac.uk)
 */
public class LinkedListICA {

    /**
     * The entry point for your program.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* This main method is intentionally left blank. You should test your
         * code using the unit tests provided, and/or write your own if you're
         * feeling up to it. You may also write code here to test your ADTs.
         */
        
        int[] list = {5 , 10 , 15 , 20 , 30};
        
        // For Singly Linked List
        System.out.printf("This is the test of Singly Linked List :\n");
        
        SinglyLinkedList testSLL = new SinglyLinkedList(list);
        System.out.printf("the size of list is : " + testSLL.getSize() + "\n");
        System.out.printf("the seconde item in the list is : " + testSLL.getSecond() + "\n");
        
        for(int i = 0; i < 5; i++){
            System.out.printf("the " + i + " item in the list is : " + testSLL.getAtPos(i) + "\n");
        }
        
        System.out.printf("add 25 after 3 is : " + testSLL.addAfterPos(25, 3) + "\n");
        System.out.printf("the size of list is : " + testSLL.getSize() + "\n");
        
        for(int i = 0; i < 6; i++){
            System.out.printf("the " + i + " item in the list is : " + testSLL.getAtPos(i) + "\n");
        }
        
        System.out.printf("add 35 after 6 is : " + testSLL.addAfterPos(35, 6) + "\n");
        System.out.printf("the size of list is : " + testSLL.getSize() + "\n");
        
        testSLL.reverseOrderLinkedList();
        
        for(int i = 0; i < 7; i++){
            System.out.printf("the " + i + " item in the list is : " + testSLL.getAtPos(i) + "\n");
        }
        
        // For Doubly Linked List
        System.out.printf("\nThis is the test of Doubly Linked List :\n");
        DoublyLinkedList emptyTestDLL = new DoublyLinkedList(new int[] {});
        System.out.printf("the list is empty : " + emptyTestDLL.isEmpty() + "\n");
        
        DoublyLinkedList testDLL = new DoublyLinkedList(list);
        System.out.printf("the list is empty : " + testDLL.isEmpty() + "\n");
        System.out.printf("the list to string is : " + testDLL.toString() + "\n");
        
        System.out.printf("add 25 at 4 is : " + testDLL.addAtPos(25, 4) + "\n");
        System.out.printf("the list to string is : " + testDLL.toString() + "\n");
        
        System.out.printf("add 0 at 0 is : " + testDLL.addAtPos(0, 0) + "\n");
        System.out.printf("the list to string is : " + testDLL.toString() + "\n");
        
        System.out.printf("deleting the multiples of 3 : " + testDLL.deleteMultiplesOfThree() + " nodes has been deleted\n");
        System.out.printf("the list to string is : " + testDLL.toString() + "\n");
        
        // For Circular Linked List
        System.out.printf("\nThis is the test of Circular Linked List :\n");
        CircularLinkedList testCLL = new CircularLinkedList(new int[] {5 , 10 , 5 , 15 , 5 , 20 , 5});
        System.out.printf("the size of list is : " + testCLL.getSize() + "\n");
        System.out.printf("the last item in the list is : " + testCLL.getLast() + "\n");
        System.out.printf("the sum of the list is : " + testCLL.sum() + "\n");
        
        System.out.printf("deleting all nodes with data 5 : " + testCLL.deleteAllNodesWithValue(5) + " nodes has been deleted\n");
        System.out.printf("the size of list is : " + testCLL.getSize() + "\n");
        System.out.printf("the last item in the list is : " + testCLL.getLast() + "\n");
        System.out.printf("the sum of the list is : " + testCLL.sum() + "\n");
        
        System.out.printf("deleting the node at 3 is : " + testCLL.deleteAtPos(3) + "\n");
        System.out.printf("deleting the node at 0 is : " + testCLL.deleteAtPos(0) + "\n");
        
        System.out.printf("the size of list is : " + testCLL.getSize() + "\n");
        System.out.printf("the last item in the list is : " + testCLL.getLast() + "\n");
        System.out.printf("the sum of the list is : " + testCLL.sum() + "\n");
    }
    
}
