package uk.ac.tees.linkedlistica;

/**
 * Represents a singly linked list.
 * @author Kylin Lu (D3013539@tees.ac.uk)
 * @author Annalisa Occhipinti (a.occhipinti@tees.ac.uk)
 */
public class DoublyLinkedList {
    
    /**
     * Stores the first node in the list.
     */
    public DoublyLinkedListNode head;
      
    /**
     * Creates a new doubly linked list from an existing array.
     * @param data  the array to create the new linked list from
     */
    public DoublyLinkedList(int[] data) {
        
        // DO NOT MODIFY THIS CONSTRUCTOR.
           
        for (int i = data.length - 1; i >= 0; i--) {
            DoublyLinkedListNode n = new DoublyLinkedListNode(data[i], head, 
                    null);
            if (head != null) {
                head.prev = n;
            }
            head = n;
        }
    }
    
    
    /**
     * Gets whether or not the list is empty.
     * @return  true if list is empty, otherwise false
     */
    public boolean isEmpty() {
        return head == null;
    }
    
    
    /**
     * Returns the list as a string of the form "{item1, item2, ...}"
     * @return  the resulting string in the format {item1, item2, ...}
     */
    @Override
    public String toString() {
        DoublyLinkedListNode p = head;
        String str = "{";
        
        while(p.next != null){
            str += p.data + ", ";
            p = p.next;
        }
        
        str += p.data + "}";
        
        return str;
    }
    
    
     /**
     * Count all nodes with the given value, returning the number of nodes.
     * @param obj   the value
     * @return      the number of nodes with value obj
     */
    public int countNodesWithValue(int obj) {
        DoublyLinkedListNode p = head;
        int count = 0;
        
        while(p != null){
            if(p.data == obj){
                count ++;
            }
            p = p.next;
        }
        
        return count;
    }
    
       
    
    /**
     * Adds an item after a specified index in the list.
     * @param obj   the item to add
     * @param index the index
     * @return      true if successful, otherwise false
     */
    public boolean addAtPos(int obj, int index) {
        // Using add at index in the document instead of after
        DoublyLinkedListNode p = head;
        
        if(index == 0){ // Case index = 0
            p = new DoublyLinkedListNode(obj, p, null);
            p.next.prev = p;
            head = p;
            return true;
        }
        else{ // Case index != 0
            for(int i = 0; i < index - 1; i++){
                if(p.next == null){
                    return false;
                }
                else{
                    p = p.next;
                }
            }

            p = new DoublyLinkedListNode(obj, p.next, p);
            p.prev.next = p;
            p.next.prev = p;

            return true;
        }
    }
    
    
     /**
     * Deletes any node containing a value that is a multiple of three.
     * @return 
     */    
    public int deleteMultiplesOfThree() {
        DoublyLinkedListNode p = head;
        DoublyLinkedListNode temp = head;
        int count = 0;
        
        // For the head node
        while(p == head){
            if(((p.data % 3) == 0) && (p.data != 0)){
                p.next.prev = null;
                head = p.next;
                p.next = null;
                p = head;
                
                count ++;
            }
            else{
                p = p.next;
            }
        }
        
        // For remain nodes
        while(p != null){
            if(((p.data % 3) == 0) && (p.data != 0)){
                temp = p;
                p = p.next;
                
                temp.prev.next = p;
                if(p != null){
                    p.prev = temp.prev;
                }
                
                temp.prev = null;
                temp.next = null;
                
                count ++;
            }
            else{
                p = p.next;
            }
        }
        
        return count;
    }
    
    
}
