package uk.ac.tees.linkedlistica;

/**
 * Represents a circular linked list.
 * @author Kylin Lu (D3013539@tees.ac.uk)
 * @author Annalisa Occhipinti (a.occhipinti@tees.ac.uk)
 */
public class CircularLinkedList {
    
    /**
     * Stores the first node in the list. Should always be a sentinel node.
     */
    public ListNode head;
    
    /**
     * Creates a new circular linked list from an existing array.
     *
     * @param data  the array to create the new linked list from
     */
    public CircularLinkedList(int[] data) {
        
        // DO NOT MODIFY THIS CONSTRUCTOR.
        
        // The head is a sentinel node.
        head = new ListNode(-999, null);
        head.next = head; // Complete the circle.
        
        // Populate list.
        ListNode n = head; // The last item in the circle.
        for (int i = 0; i < data.length; i++) {
            n.next = new ListNode(data[i], head);
            n = n.next;
        }
    }
    
    
    /**
     * Gets the length of the circular linked list.
     * @return  the length
     */
    public int getSize() {
        ListNode p = head;
        int size = 0;
        
        while(p.next != head){
            size ++;
            p = p.next;
        }
        
        return size;
    }
    
    /**
     * Gets the last item in the circular linked list, or -999 if not found.
     * @return  the last item, or -999 if empty
     */
    public int getLast() {
        ListNode p = head;
        
        while(p.next != head){
            p = p.next;
        }
        
        return p.data;
    }
    
    
     /**
     * Deletes all nodes with the given value, returning the number of nodes
     * deleted.
     * @param obj   the value
     * @return      the number of nodes deleted
     */
    public int deleteAllNodesWithValue(int obj) {
        ListNode p = head.next;
        ListNode temp = head;
        int count = 0;
        
        while(p != head){
            if(p.data == obj){
                temp.next = p.next;
                p.next = null;
                p = temp.next;
                
                count ++;
            }
            else{
                temp = p;
                p = p.next;
            }
        }
        
        return count;
    }
    
    
     /**
     * Deletes the node in the list at the specified index.
     * @param index the index
     * @return      true if successful, otherwise false
     */
    public boolean deleteAtPos(int index) {
        ListNode p = head.next;
        ListNode temp = head;
        
        for(int i = 0; i < index; i ++){
            if(p == head){
                return false;
            }
            else{
                temp = p;
                p = p.next;
            }
        }
        
        if(p == head){
                return false;
            }
            else{
                temp.next = p.next;
                p.next = null;

                return true;
        }
    }
    
    
    
    
     /**
     * Returns the sum of all integers in the list.
     * @return  the sum
     */
    public int sum() {
        ListNode p = head.next;
        int sum = 0;
        
        while(p != head){
            sum += p.data;
            p = p.next;
        }
        
        return sum;
    }
    
}
